    <?php
        $pageTitle = "Clean Me | Booking Packge";
        include_once("includes/main.php"); 
        include_once("includes/header.php"); 
    ?>

    <?php
        $response = "<label style='font-size: 30px;'>Sorry but you must be logged in to book.<br><br>
        <a href='login.php'>Login Here</a> | or | <a href='signup.php'>Sign Up Here</a>
        <br></label>";
        if(isset($_GET['id'])){
            $query = "select * from products where id = '".$_GET['id']."'";
            $result = mysqli_query($con, $query);
            
            $count = mysqli_num_rows($result);
            if($count > 0){
                $description = "";
                $price = "";
                while($row = mysqli_fetch_array($result)){
                    $description = $row['description'];
                    $price = $row['price'];
                }
                
                if(isset($_SESSION['username']) && isset($_SESSION['password'])){
                    $username = $_SESSION['username'];
                    $password = $_SESSION['password'];
                    
                    $query = "select * from users where password = '$password' and username = '$username'";
                    $result = mysqli_query($con, $query);
                    $count = mysqli_num_rows($result);
                    if($count > 0){
                        $response = "<label style='font-size: 20px;'>
                            Please confirm the details:<br>
                            <b>Description:</b> ".$description."<br><br> 
                            <b>Price:</b> ".$price."<br><br>
                            
                            <a href='checkout.php?id=".$_GET['id']."'>Check out now</a><br><br><br>
                        </label>";
                    }
                }
            }else{
                header("location: book.php");                
            }
        }else{
            header("location: book.php");
        }
    ?>
<body>
    <div class="container">
        <?php include_once("includes/menu.php"); ?>
    </div>
    <div class="container" style="margin-top: 50px;">
        <h1>Booking package with ID <?php echo $_GET['id']; ?></h1><br>
        
        <?php echo $response; ?>
    </div>

    <!-- /container -->
    <script>
        //  The function to change the class
        var changeClass = function (r,className1,className2) {
            var regex = new RegExp("(?:^|\\s+)" + className1 + "(?:\\s+|$)");
            if( regex.test(r.className) ) {
                r.className = r.className.replace(regex,' '+className2+' ');
            }
            else{
                r.className = r.className.replace(new RegExp("(?:^|\\s+)" + className2 + "(?:\\s+|$)"),' '+className1+' ');
            }
            return r.className;
        };	

        //  Creating our button in JS for smaller screens
        var menuElements = document.getElementById('menu');
        menuElements.insertAdjacentHTML('afterBegin','<button type="button" id="menutoggle" class="navtoogle" aria-hidden="true"><i aria-hidden="true" class="icon-menu"> </i> Menu</button>');

        //  Toggle the class on click to show / hide the menu
        document.getElementById('menutoggle').onclick = function() {
            changeClass(this, 'navtoogle active', 'navtoogle');
        }

        // http://tympanus.net/codrops/2013/05/08/responsive-retina-ready-menu/comment-page-2/#comment-438918
        document.onclick = function(e) {
            var mobileButton = document.getElementById('menutoggle'),
                buttonStyle =  mobileButton.currentStyle ? mobileButton.currentStyle.display : getComputedStyle(mobileButton, null).display;
            if(buttonStyle === 'block' && e.target !== mobileButton && new RegExp(' ' + 'active' + ' ').test(' ' + mobileButton.className + ' ')) {
                changeClass(mobileButton, 'navtoogle active', 'navtoogle');
            }
        }
    </script>
</body>
</html>