    <?php
        $pageTitle = "Clean Me | Our Products, Book Now.";
        include_once("includes/main.php"); 
        include_once("includes/header.php"); 
    ?>
    <?php
        $query = "select * from products";
        $result = mysqli_query($con, $query);
        $data = "
            <table width='80%' align='center'>
            <tr>
        ";
        $i = 0;
        while($row = mysqli_fetch_array($result)){
            if($i %2 == 0){
                $data .= "</tr><tr>";
            }
            
            $data .= "
                <td>
                    ".$row['description']."<br><br>
                    
                    <label style='color: #F00; font-size: 30px;'>Price ".$row['price']."</label><br><br>
                    <label style='font-size: 20px;'><a href='bookid.php?id=".$row['id']."'>Book Package</a></label>
                </td>
            ";
            $i++;
        }

        $data .= "</table>";
    ?>

<body>
    <div class="container">
        <?php include_once("includes/menu.php"); ?>
    </div>
    <div class="container" style="margin-top: 50px;">
        <h1>Here is our Products.</h1><br>
        <?php echo $data; ?>
    </div>

    <!-- /container -->
    <script>
        //  The function to change the class
        var changeClass = function (r,className1,className2) {
            var regex = new RegExp("(?:^|\\s+)" + className1 + "(?:\\s+|$)");
            if( regex.test(r.className) ) {
                r.className = r.className.replace(regex,' '+className2+' ');
            }
            else{
                r.className = r.className.replace(new RegExp("(?:^|\\s+)" + className2 + "(?:\\s+|$)"),' '+className1+' ');
            }
            return r.className;
        };	

        //  Creating our button in JS for smaller screens
        var menuElements = document.getElementById('menu');
        menuElements.insertAdjacentHTML('afterBegin','<button type="button" id="menutoggle" class="navtoogle" aria-hidden="true"><i aria-hidden="true" class="icon-menu"> </i> Menu</button>');

        //  Toggle the class on click to show / hide the menu
        document.getElementById('menutoggle').onclick = function() {
            changeClass(this, 'navtoogle active', 'navtoogle');
        }

        // http://tympanus.net/codrops/2013/05/08/responsive-retina-ready-menu/comment-page-2/#comment-438918
        document.onclick = function(e) {
            var mobileButton = document.getElementById('menutoggle'),
                buttonStyle =  mobileButton.currentStyle ? mobileButton.currentStyle.display : getComputedStyle(mobileButton, null).display;
            if(buttonStyle === 'block' && e.target !== mobileButton && new RegExp(' ' + 'active' + ' ').test(' ' + mobileButton.className + ' ')) {
                changeClass(mobileButton, 'navtoogle active', 'navtoogle');
            }
        }
    </script>
</body>
</html>