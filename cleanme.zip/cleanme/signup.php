    <?php
        $pageTitle = "Clean Me | Create Account";
        include_once("includes/main.php"); 
        include_once("includes/header.php"); 
    ?>

    <?php
        $error = "";
        
        if(isset($_POST['submit'])){
            $full_names = $_POST['full_names'];
            $username = $_POST['username'];
            $password1 = $_POST['password1'];
            $password2 = $_POST['password2'];
            
            if($password1 == $password2){
                $query = "insert into users(full_names, username, password) values('$full_names', '$username', '$password1')";
                $result = mysqli_query($con, $query);
                if($result){
                    $error = "<label style='color: #0F0;'>Account created. Proceed to login.</label>";
                }else{
                    $error = "<label style='color: #F00;'>Error creating account, the username is taken</label>";
                }
            }else{
                $error = "<label style='color: #F00;'>Error passwords dont match</label>";                
            }
        }
    ?>
<body>
    <div class="container">
        <?php include_once("includes/menu.php"); ?>
    </div>
    <div class="container" style="margin-top: 50px;">
        <center><?php echo $error; ?></center>
        <form method="post" action="signup.php">
            <table width="100%">
                <tr>
                    <td width="20%">Full Names *</td>
                    <td width="80%"><input type="text" name="full_names" required></td>
                </tr>
                <tr>
                    <td width="20%">Username *</td>
                    <td width="80%"><input type="text" name="username" required></td>
                </tr>
                <tr>
                    <td width="20%">Password *</td>
                    <td width="80%"><input type="password" name="password1" required></td>
                </tr>
                <tr>
                    <td width="20%">Confirm Password *</td>
                    <td width="80%"><input type="password" name="password2" required></td>
                </tr>
                <tr>
                    <td width="20%"></td>
                    <td width="80%">
                        <input type="submit" name="submit" value="Create Account"><br><br>
                        Have an account, <a href="login.php">Login Here.</a>
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <!-- /container -->
    <script>
        //  The function to change the class
        var changeClass = function (r,className1,className2) {
            var regex = new RegExp("(?:^|\\s+)" + className1 + "(?:\\s+|$)");
            if( regex.test(r.className) ) {
                r.className = r.className.replace(regex,' '+className2+' ');
            }
            else{
                r.className = r.className.replace(new RegExp("(?:^|\\s+)" + className2 + "(?:\\s+|$)"),' '+className1+' ');
            }
            return r.className;
        };	

        //  Creating our button in JS for smaller screens
        var menuElements = document.getElementById('menu');
        menuElements.insertAdjacentHTML('afterBegin','<button type="button" id="menutoggle" class="navtoogle" aria-hidden="true"><i aria-hidden="true" class="icon-menu"> </i> Menu</button>');

        //  Toggle the class on click to show / hide the menu
        document.getElementById('menutoggle').onclick = function() {
            changeClass(this, 'navtoogle active', 'navtoogle');
        }

        // http://tympanus.net/codrops/2013/05/08/responsive-retina-ready-menu/comment-page-2/#comment-438918
        document.onclick = function(e) {
            var mobileButton = document.getElementById('menutoggle'),
                buttonStyle =  mobileButton.currentStyle ? mobileButton.currentStyle.display : getComputedStyle(mobileButton, null).display;
            if(buttonStyle === 'block' && e.target !== mobileButton && new RegExp(' ' + 'active' + ' ').test(' ' + mobileButton.className + ' ')) {
                changeClass(mobileButton, 'navtoogle active', 'navtoogle');
            }
        }
    </script>
</body>
</html>