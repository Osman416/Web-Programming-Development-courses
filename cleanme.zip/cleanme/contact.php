    <?php
        $pageTitle = "Clean Me | Contact Us";
        include_once("includes/main.php"); 
        include_once("includes/header.php"); 
    ?>

    <?php
        $error = "";
        
        if(isset($_POST['submit'])){
            $full_names = $_POST['full_names'];
            $subject = $_POST['subject'];
            $message = $_POST['message'];
            
            $query = "insert into contacts(full_names, subject, message, date, status) values('$full_names', '$subject', '$message', now(), 'unread')";
            $result = mysqli_query($con, $query);
            if($result){
                $error = "<label style='color: #0F0;'>Message Sent. Thank you.</label>";
            }else{
                $error = "<label style='color: #F00;'>Error sending message</label>";
            }
        }
    ?>
<body>
    <div class="container">
        <?php include_once("includes/menu.php"); ?>
    </div>
    <div class="container" style="margin-top: 50px;">
        <center><?php echo $error; ?></center>
        <form method="post" action="contact.php">
            <table width="100%">
                <tr>
                    <td width="20%">Full Names *</td>
                    <td width="80%"><input type="text" name="full_names" required></td>
                </tr>
                <tr>
                    <td width="20%">Subject *</td>
                    <td width="80%"><input type="text" name="subject" required></td>
                </tr>
                <tr>
                    <td width="20%" valign="top">Message *</td>
                    <td width="80%">
                        <textarea name="message" required placeholder="Message" cols="20" rows="8"></textarea>
                    </td>
                </tr>
                <tr>
                    <td width="20%"></td>
                    <td width="80%">
                        <input type="submit" name="submit" value="Send Message">
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <!-- /container -->
    <script>
        //  The function to change the class
        var changeClass = function (r,className1,className2) {
            var regex = new RegExp("(?:^|\\s+)" + className1 + "(?:\\s+|$)");
            if( regex.test(r.className) ) {
                r.className = r.className.replace(regex,' '+className2+' ');
            }
            else{
                r.className = r.className.replace(new RegExp("(?:^|\\s+)" + className2 + "(?:\\s+|$)"),' '+className1+' ');
            }
            return r.className;
        };	

        //  Creating our button in JS for smaller screens
        var menuElements = document.getElementById('menu');
        menuElements.insertAdjacentHTML('afterBegin','<button type="button" id="menutoggle" class="navtoogle" aria-hidden="true"><i aria-hidden="true" class="icon-menu"> </i> Menu</button>');

        //  Toggle the class on click to show / hide the menu
        document.getElementById('menutoggle').onclick = function() {
            changeClass(this, 'navtoogle active', 'navtoogle');
        }

        // http://tympanus.net/codrops/2013/05/08/responsive-retina-ready-menu/comment-page-2/#comment-438918
        document.onclick = function(e) {
            var mobileButton = document.getElementById('menutoggle'),
                buttonStyle =  mobileButton.currentStyle ? mobileButton.currentStyle.display : getComputedStyle(mobileButton, null).display;
            if(buttonStyle === 'block' && e.target !== mobileButton && new RegExp(' ' + 'active' + ' ').test(' ' + mobileButton.className + ' ')) {
                changeClass(mobileButton, 'navtoogle active', 'navtoogle');
            }
        }
    </script>
</body>
</html>