var $ = jQuery.noConflict();

$(document).ready(function($) {
	"use strict";
	
    /* ---------------------------------------------------------------------- */
    /*  Contact Form
    /* ---------------------------------------------------------------------- */

    var submitContact = $('#submit_contact'),
        message = $('#msg');

    submitContact.on('click', function(e){
        e.preventDefault();

        var $this = $(this);
        
        $.ajax({
            type: "POST",
            url: 'contact.php',
            dataType: 'json',
            cache: false,
            data: $('#contact-form').serialize(),
            success: function(data) {

                if(data.info !== 'error'){
                    $this.parents('form').find('input[type=text],textarea,select').filter(':visible').val('');
                    message.hide().removeClass('success').removeClass('error').addClass('success').html(data.msg).fadeIn('slow').delay(5000).fadeOut('slow');
                } else {
                    message.hide().removeClass('success').removeClass('error').addClass('error').html(data.msg).fadeIn('slow').delay(5000).fadeOut('slow');
                }
            }
        });
    });

    /* ---------------------------------------------------------------------- */
    /*  Contact Map
    /* ---------------------------------------------------------------------- */

    
    var myMarkers = {
        "markers": [
            {
                "latitude": "43.649954",       // latitude
                "longitude":"-79.3528449",       // longitude
                "icon": "images/map_pin_1.png"  // Pin icon
            }
             

            // Add As Plenty As u want
            , {
                "latitude": "43.6425546",
                "longitude":"-79.3826729",
                "icon": "images/map_pin_1.png"
            }
            , {
                "latitude": "43.670863",
                "longitude":"-79.3958794",
                "icon": "images/map_pin_1.png"
            }
            
            
        ]
    };

    try {
        $("#google_map").mapmarker({
            zoom : 14,                          // Zoom
            center: "43.649954,-74.79.3528449",        // Center of map
            type: "ROADMAP",                    // Map Type
            controls: "HORIZONTAL_BAR",         // Controls style
            dragging:1,                         // Allow dragging?
            mousewheel:0,                       // Allow zooming with mousewheel
            markers: myMarkers,
            styling: 0,                         // Bool - do you want to style the map?
            featureType:"all",
            visibility: "on",
            elementType:"geometry",
            hue:"#00AAFF",
            saturation:-100,
            lightness:0,
            gamma:1,
            navigation_control:0
            /*
            To play with the map colors and styles you can try this tool right here http://gmaps-samples-v3.googlecode.com/svn/trunk/styledmaps/wizard/index.html
            */
        });

    } catch(err) {
    }
    

});
