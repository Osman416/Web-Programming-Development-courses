<?php
    include_once("includes/main.php"); 
    session_destroy();

    header("location: book.php");
?>