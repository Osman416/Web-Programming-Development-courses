<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title><?php echo $pageTitle; ?></title>
		<meta name="description" content="Responsive Retina-Friendly Menu with different, size-dependent layouts" />
		<meta name="keywords" content="responsive menu, retina-ready, icon font, media queries, css3, transition, mobile" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico"> 
		<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<script src="js/modernizr.custom.js"></script>
		
		<link rel='stylesheet' href='revslider/rs-plugin/css/settings.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/instag-slider.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/style.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/layout.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/main.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/shortcodes.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/mediaelementplayer.min.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/woocommerce.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/prettyPhoto.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/responsive.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/js_composer.css' type='text/css' media='all'/>
        <link rel='stylesheet' href='css/default.css' type='text/css' media='screen'/>
        <link rel='stylesheet' href='css/fontawesome.css' type='text/css' media='screen'/>
        <link rel='stylesheet' href='css/font-awesome.css' type='text/css' media='screen'/>
        <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>

		<style>
            .footer {
                text-align:center;
            }
		</style>
	</head>
