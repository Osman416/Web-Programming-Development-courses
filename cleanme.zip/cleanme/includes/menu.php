        <!-- logo -->
        <header>
            <div class="logo-container">
                <a style="float: left; margin-left: 30px;" href="index.php">
                    <img src="images/logo.png" class="default-logo" alt="CleanMe">
                </a>
                <label style="float: right; margin-right: 60px; margin-top: 60px;">
                    CleanMe Mobile Service <font color="green">Welcome 
                    <?php
                        if(isset($_SESSION['username']) && isset($_SESSION['password'])){
                            $username = $_SESSION['username'];
                            $password = $_SESSION['password'];
                    
                            $query = "select * from users where password = '$password' and username = '$username'";
                            $result = mysqli_query($con, $query);
                            $count = mysqli_num_rows($result);
                            if($count > 0){
                                $names = "";
                                while($row = mysqli_fetch_array($result)){
                                    $names = $row['full_names'];
                                }
                                
                                $names .= "  <a href='logout.php'>Log out.</a>";
                                
                                echo $names;
                            }
                        }
                    ?>
                    !</font>
                </label>
            </div>
        </header>
        <div style="clear: both;">
            <nav id="menu" class="nav">					
                <ul>
                    <li>
                        <a href="index.php">
                            <span class="icon">
                                <i aria-hidden="true" class="icon-home"></i>
                            </span>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="services.php">
                            <span class="icon"> 
                                <i aria-hidden="true" class="icon-services"></i>
                            </span>
                            <span>Services</span>
                        </a>
                    </li>
                    <li>
                        <a href="portfolio.php">
                            <span class="icon">
                                <i aria-hidden="true" class="icon-portfolio"></i>
                            </span>
                            <span>Portfolio</span>
                        </a>
                    </li>
                    <li>
                        <a href="book.php">
                            <span class="icon">
                                <i aria-hidden="true" class="icon-blog"></i>
                            </span>
                            <span>Book Now</span>
                        </a>
                    </li>
                    <li>
                        <a href="team.php">
                            <span class="icon">
                                <i aria-hidden="true" class="icon-team"></i>
                            </span>
                            <span>The team</span>
                        </a>
                    </li>
                    <li>
                        <a href="contact.php">
                            <span class="icon">
                                <i aria-hidden="true" class="icon-contact"></i>
                            </span>
                            <span>Contact</span>
                        </a>
                    </li>
                </ul>
            </nav>				
        </div>
