﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (PreviousPage != null)
        {
            ///get info from previous page......
            double totalAssets = 0;
            TextBox asset1 = (TextBox)PreviousPage.FindControl("txtGrossIncome");
            TextBox asset2 = (TextBox)PreviousPage.FindControl("txtValueOfAssets");
            TextBox asset3 = (TextBox)PreviousPage.FindControl("txtInvestments");
            TextBox asset4 = (TextBox)PreviousPage.FindControl("txtOtherIncome");

            TextBox fname = (TextBox)PreviousPage.FindControl("txtFirstName");
            TextBox lname = (TextBox)PreviousPage.FindControl("txtLastName");

            TextBox liabilities = (TextBox)PreviousPage.FindControl("txtTotalLiabilities");
            TextBox totalLoanAmount = (TextBox)PreviousPage.FindControl("txtLoanAmount");
            TextBox interestRate = (TextBox)PreviousPage.FindControl("txtRate");
            // end getting info from previous page
            totalAssets = totalAssets + Convert.ToDouble("0" + asset1.Text) + Convert.ToDouble("0" + asset2.Text) + Convert.ToDouble("0" + asset3.Text) + Convert.ToDouble("0" + asset4.Text);
            lblFirstname.Text = fname.Text;
            lblLastname.Text = lname.Text;
            lblTotalAssets.Text = "" + totalAssets;
            lblTotalLiabilities.Text = liabilities.Text;
            lblLoanAmount.Text = totalLoanAmount.Text;
            lblInterestRate.Text = interestRate.Text;

            if (checkApproval(totalAssets, Convert.ToDouble("0" + liabilities.Text)))
                lblResult.Text = "Approved";
            else
                lblResult.Text = "Denied";
        }
    }

    protected bool checkApproval(double assets, double liabilities)
    {
        if (assets < liabilities)
            return false;
        return true;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Server.Transfer("Default.aspx");
    }
}