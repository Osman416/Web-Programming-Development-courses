﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        Boolean result = true;
        Char[] convertedString = args.Value.ToCharArray();
        if (convertedString.Length != 6) result = false;
        else
        {
            for (int x = 0; x < 6; x++)
            {
                char val = convertedString[x];
                if (x % 2 == 0)   // if x is even
                {
                    if (!((val >= 'a' && val <= 'z') || (val >= 'A' && val <= 'Z'))) result = false;
                }
                 else
                    if (!(val >= '0' && val <= '9')) result = false;
            }
        }
        args.IsValid = result;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            Server.Transfer("Report.aspx");

        }
    }
}