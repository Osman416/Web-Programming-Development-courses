﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ErrorLabel.Text = "";
    }

    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        ErrorLabel.Text = "";
        if (e.Exception != null)
        {
            ErrorLabel.Text = "A database error has occured";
            e.ExceptionHandled = true;
            e.KeepInEditMode = true;
        }
        else if (e.AffectedRows == 0)
        {
            ErrorLabel.Text = "Another user may have updated this row already." + "<br/> Please try again";
        }

    }
    protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        ErrorLabel.Text = "";
        if (e.Exception != null)
        {
            ErrorLabel.Text = "A database error has occured";
            e.ExceptionHandled = true;

        }
        else if (e.AffectedRows == 0)
        {
            ErrorLabel.Text = "Another user may have updated this row already." + "<br/> Please try again";
        }
    }

    /*
    protected void DetailsView1_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
    {
        ErrorLabel.Text = "";
        if (e.Exception != null)
        {
            ErrorLabel.Text = "A database error has occured";
            e.ExceptionHandled = true;
        }
        else if (e.AffectedRows == 0)
        {
            ErrorLabel.Text = "Another user may have updated this row already." + "<br/> Please try again";
        }
        GridView1.DataBind();
    }
    protected void DetailsView1_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
    {
        ErrorLabel.Text = "";
        if (e.Exception != null)
        {
            ErrorLabel.Text = "A database error has occured";
            e.ExceptionHandled = true;
        }
        else if (e.AffectedRows == 0)
        {
            ErrorLabel.Text = "Another user may have updated this row already." + "<br/> Please try again";
        }
        GridView1.DataBind();

    }
     */
}